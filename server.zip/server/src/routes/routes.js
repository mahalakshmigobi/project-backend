
const express=require('express')
const router=express.Router();


const moviecontroller=require('../controller/controller');

//defining routes
router.get('/movie',moviecontroller.getallmovies);
router.get('/movie/:id',moviecontroller.getmovies);
router.post('/movie',moviecontroller.createmovies);
router.patch('/movie',moviecontroller.updatemovies);
router.delete('/movie/:id',moviecontroller.deletemovies);

module.exports=router;