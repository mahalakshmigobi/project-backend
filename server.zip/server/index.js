const express=require('express');
const { default: mongoose } = require('mongoose');

const app=express();
const PORT=3200||4040;


app.use(express.json());

const ConnectDB=require('./src/config/db');
ConnectDB();

const routes=require('./src/routes/routes');
app.use('/dashboard',routes);

app.listen(PORT,()=>{
    console.log('welcome to dashboard'+ PORT);
});














